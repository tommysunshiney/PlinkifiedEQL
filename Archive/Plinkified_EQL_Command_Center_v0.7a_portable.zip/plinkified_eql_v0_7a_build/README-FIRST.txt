PLINKIFIED EQL COMMAND CENTER v0.7a — FIRST DESKTOP ALPHA

Run:
  Plinkified EQL Command Center v0.7a.exe

What this build is:
  • A portable Windows EXE launcher containing the complete v0.7a Command Center.
  • It extracts its embedded app to:
      %LOCALAPPDATA%\PlinkifiedEQL\
    and opens it in your default browser.
  • Your existing browser-based features remain available.

Important alpha note:
  This is the fast-update launcher build, not yet the full native desktop shell.
  Native always-remembered folder paths, direct filesystem monitoring, and the
  polished Main / Adventure Journal / Settings desktop tabs are the next build step.

Suggested location:
  Documents\PlinkifiedEQL\

You can keep the old HTML file in archive after confirming this launches correctly.
