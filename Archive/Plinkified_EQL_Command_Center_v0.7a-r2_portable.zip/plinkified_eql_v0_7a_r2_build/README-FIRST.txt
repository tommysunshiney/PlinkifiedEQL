PLINKIFIED EQL COMMAND CENTER v0.7a-r2

1. Double-click "Plinkified EQL Command Center v0.7a-r2.exe".
2. Windows SmartScreen may show a warning because this homemade alpha is unsigned.
   Choose More info > Run anyway.
3. This alpha still opens the Command Center in your default browser.

This revision changes:
- "Flags the exact timer" now says "Flags the exact time."
- Resetting the session clock also resets the camp clock.
- Resetting only the camp clock leaves the session clock running.
- The ShareX selection is now a read-only display instead of an editable text box.
- The splash-screen clickable Continue area was realigned.

CURRENT DATA LOCATION
The launcher writes its embedded app to:
%LOCALAPPDATA%\PlinkifiedEQL\plinkified_eql_command_center_v0_7a.html

Journal/settings data are still stored by your browser in localStorage and IndexedDB,
not inside the EXE folder. Exported JSON/CSV files go to your browser's normal
Downloads location unless you choose otherwise.
