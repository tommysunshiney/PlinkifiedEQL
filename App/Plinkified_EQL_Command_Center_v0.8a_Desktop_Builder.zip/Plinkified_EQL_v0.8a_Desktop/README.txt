PLINKIFIED EQL COMMAND CENTER v0.8a DESKTOP ALPHA

1. Extract this entire folder.
2. Double-click BUILD_AND_RUN_v0.8a.cmd.
3. It downloads the official Electron Windows runtime once, creates the EXE, and starts the app.
4. After that, run Plinkified EQL Command Center v0.8a.exe directly.

App data is stored at:
Documents\PlinkifiedEQL\Data\plinkified-state.json

The portable folder must stay together. This alpha is unsigned, so Windows may warn you.
