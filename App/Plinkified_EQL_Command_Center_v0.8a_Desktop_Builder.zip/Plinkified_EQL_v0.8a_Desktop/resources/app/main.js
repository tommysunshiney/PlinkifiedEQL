const { app, BrowserWindow, ipcMain, dialog, Menu } = require('electron');
const path = require('path');
const fs = require('fs');

const docsRoot = path.join(app.getPath('documents'), 'PlinkifiedEQL');
const dataDir = path.join(docsRoot, 'Data');
const exportsDir = path.join(docsRoot, 'Exports');
const backupsDir = path.join(docsRoot, 'Backups');
const statePath = path.join(dataDir, 'plinkified-state.json');
for (const dir of [docsRoot, dataDir, exportsDir, backupsDir]) fs.mkdirSync(dir, { recursive: true });

function readState() {
  try { return JSON.parse(fs.readFileSync(statePath, 'utf8')); }
  catch { return {}; }
}
function writeState(state) {
  const tmp = statePath + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(state, null, 2), 'utf8');
  fs.renameSync(tmp, statePath);
  return true;
}

let win;
function createWindow() {
  win = new BrowserWindow({
    width: 1500,
    height: 950,
    minWidth: 900,
    minHeight: 650,
    title: 'Plinkified EQL Command Center v0.8a',
    backgroundColor: '#10091b',
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webSecurity: false
    }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
  win.on('maximize', () => win.webContents.send('window-state', 'maximized'));
  win.on('unmaximize', () => win.webContents.send('window-state', 'normal'));
}

app.whenReady().then(() => {
  Menu.setApplicationMenu(null);
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });

ipcMain.handle('state-load', () => ({ state: readState(), statePath, docsRoot }));
ipcMain.handle('state-save', (_e, state) => writeState(state));
ipcMain.handle('choose-folder', async (_e, title) => {
  const r = await dialog.showOpenDialog(win, { title: title || 'Choose Folder', properties: ['openDirectory', 'createDirectory'] });
  return r.canceled ? null : r.filePaths[0];
});
ipcMain.handle('choose-images', async () => {
  const r = await dialog.showOpenDialog(win, {
    title: 'Choose Screenshot(s)',
    properties: ['openFile', 'multiSelections'],
    filters: [{ name: 'Images', extensions: ['png','jpg','jpeg','webp','gif','bmp'] }]
  });
  return r.canceled ? [] : r.filePaths;
});
ipcMain.handle('export-json', async (_e, data) => {
  const r = await dialog.showSaveDialog(win, {
    title: 'Export Adventure Journal',
    defaultPath: path.join(exportsDir, `plinkified-journal-${new Date().toISOString().slice(0,10)}.json`),
    filters: [{ name: 'JSON', extensions: ['json'] }]
  });
  if (r.canceled || !r.filePath) return null;
  fs.writeFileSync(r.filePath, JSON.stringify(data, null, 2), 'utf8');
  return r.filePath;
});
ipcMain.handle('toggle-fullscreen', () => { win.setFullScreen(!win.isFullScreen()); return win.isFullScreen(); });
ipcMain.handle('toggle-maximize', () => { if (win.isMaximized()) win.unmaximize(); else win.maximize(); return win.isMaximized(); });
ipcMain.handle('open-data-folder', async () => { require('electron').shell.openPath(docsRoot); return docsRoot; });
