const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('plink', {
  loadState: () => ipcRenderer.invoke('state-load'),
  saveState: (s) => ipcRenderer.invoke('state-save', s),
  chooseFolder: (t) => ipcRenderer.invoke('choose-folder', t),
  chooseImages: () => ipcRenderer.invoke('choose-images'),
  exportJSON: (d) => ipcRenderer.invoke('export-json', d),
  toggleFullscreen: () => ipcRenderer.invoke('toggle-fullscreen'),
  toggleMaximize: () => ipcRenderer.invoke('toggle-maximize'),
  openDataFolder: () => ipcRenderer.invoke('open-data-folder')
});
