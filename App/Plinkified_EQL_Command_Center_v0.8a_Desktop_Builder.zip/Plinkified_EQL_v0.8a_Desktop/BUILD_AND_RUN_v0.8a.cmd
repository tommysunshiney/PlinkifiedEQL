@echo off
setlocal
cd /d "%~dp0"
set "ZIP=electron-v42.3.0-win32-x64.zip"
set "URL=https://github.com/electron/electron/releases/download/v42.3.0/electron-v42.3.0-win32-x64.zip"
if exist "Plinkified EQL Command Center v0.8a.exe" goto run

echo.
echo  Building Plinkified EQL Command Center v0.8a Desktop...
echo  This downloads the official Electron Windows runtime once.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%URL%' -OutFile '%ZIP%'"
if errorlevel 1 goto fail
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -LiteralPath '%ZIP%' -DestinationPath '.' -Force"
if errorlevel 1 goto fail
del "%ZIP%" >nul 2>&1
ren electron.exe "Plinkified EQL Command Center v0.8a.exe"
:run
start "" "Plinkified EQL Command Center v0.8a.exe"
exit /b 0
:fail
echo.
echo Build failed. Check your internet connection and try again.
pause
exit /b 1
